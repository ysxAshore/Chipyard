package gc_acc

import chisel3._

trait GCParameters{
    // TaskQueue
    val TaskEntry = 64
    val CopyEntry = 16
    val gcDataWidth = 64
    val reqNum = 16  // 最多发多少个读请求
    //val spillNeed = TaskEntry / 4 * 3  // org
    //val readNeed = TaskEntry / 2  // org
    val spillNeed = 63
    val readNeed = 8

    val ConfigStackTop = 0
    val ConfigStackBottom = 1
    val ConfigToSpace = 2
    val ConfigStart = 3

    val Mark = 3
    val IntWidth = 32

    // klass地址是否对齐？
    // -XX:-UseCompressedOops -XX:-UseCompressedClassPointers
    // klass + offset
  /*  val _layout_helper = 8   // 访存数据取int类型，bytes，数据用于计算size
    val _klass_id = 12  // 访存数据取int类型，数据用于识别klass类型

    val _vtable_len = 160 // 访存数据取int类型  不同版本位置还不一样，有的20？（jdk17u-ls）那是不是可以调整布局方便取数据

    val _nonstatic_oop_map_size = 296  // 访存数据取int类型，word，取回的数据为_nonstatic_oop_map_count
    val _itable_len = 300 // 访存数据取int类型

    val _vtable_off = 464 // 访存数据取int类型 bytes = sizeof(InstanceKlass) sizeof(Klass)=208
    // _nonstatic_oop_map_start_off = _vtable_off + (_vtable_len + _itable_len)*8
    // klass+_nonstatic_oop_map_start_off，访存取int型off+int型count，用于计算引用位置，共取_nonstatic_oop_map_count个（off,count）对

    // obj + offset
    val _oop_size_offset = 36  // 访存数据取int类型，byte，关闭压缩指针之后是36,使用压缩指针是32，数据用于取size，取回的数据为word单位
    
    val _static_oop_field_count_offset = 40 //访存数据取int类型，数据为静态引用类型数量

    val _offset_of_static_fields = 184  // InstanceMirrorKlass， 是不是一个固定的值啊，通过obj+offset来找到java.lang.Class对象的静态引用字段开始的位置
    // 初始阶段为0，但GC时一定不为0
*/
    // GC时对于 数组对象 遍历逻辑比较简单： 基本元素数组不进行遍历 对象数组 根据元素长度 一个一个遍历即可
    // GC时对于 非数组对象 因为这些对象在内存中的存储是 头部(markWord + _metadata) + 各个字段的值
    // 那么 GC 怎么知道 哪些字段是 oop, 哪些不是呢? —— 通过Oop Map
    // 每个InstanceKlass都有一张对象布局表(Oop Map), 记录oop字段的偏移量列表
    // 因此 对于非数组对象 需要 读取它的 OopMap 在Vtable之后
    // 也就是OopMap_address = Vtable_address + Vtable_len

    /* oopDesc
    class oopDesc {
        volatile markWord _mark; //markWord 有 一个uintptr_t _value; 8B
        union _metadata {
          Klass*      _klass;
          narrowKlass _compressed_klass;
        } _metadata;
        ...
    } // oopDesc 没有虚函数
    */
    val MarkWordOff = 0
    val KlassOff = 8

    /*
    // The layout of array Oops is:
    //
    //  markWord
    //  Klass*    // 32 bits if compressed but declared 64 in LP64.
    //  length    // shares klass memory or allocated after declared fields.
    考虑到内存对齐 在64位系统下 不管使不使用 压缩Klass length都是在 对象地址+16B 后
     */
    val ArrayLenOff = 16
    val ArrayElementOff = 24

    /* MirrorKlass
    注入到Class对象中的
    因为InstanceMirrorKlass对象是专门用于java.lang.Class实例的InstanceKlass,是比较特殊的. 因为:
        它们除了包含Class的常规字段外,还包含该类的静态字段,因此是大小可变的实例 对象大小是单独存储在某块区域
    #define CLASS_INJECTED_FIELDS(macro)                                       \
      macro(java_lang_Class, klass,                  intptr_signature,  false) \ 16-23 用于指回到其对应的InstanceKlass对象。这样，klass与mirror之间就有双向引用，可以来回导航
      macro(java_lang_Class, array_klass,            intptr_signature,  false) \ 24-31 同klass作用
      macro(java_lang_Class, oop_size,               int_signature,     false) \ 32-35
      macro(java_lang_Class, static_oop_field_count, int_signature,     false) \ 36-40
      macro(java_lang_Class, source_file,            object_signature,  false) \
      macro(java_lang_Class, init_lock,              object_signature,  false)
    */
    val OopSizeOff = 32
    val StaticOopFieldCountOff = 40 //@todo 这里不应该是36吗

    /* MarkWord
    class markWord {
        private:
            uintptr_t _value;
        ...
    */

    /*Klass
    class Klass : public Metadata {
          ...
          0x0: vptr
          // For klasses which are neither instance nor array, the value is zero.
          // For instances, layout helper is a positive number, the instance size.
          // For arrays, layout helper is a negative number(bit 31 is one), containing four bytes
          //    distinct bytes, as follows:
          //      MSB:[tag, hsz, ebt, log2(esz)]:LSB
          //        tag: is 0x80 if the elements are oops, 0xc0 if non-oops
          //        hsz: is array heaer size in bytes(i.e., offset of first element)
          //        ebt: is the BasicType of the elements
          //        esz: is the element size in bytes, log2
          0x8:jint _layout_helper;

          // Klass kind used to resolve the runtime type of the instance.
          //  - Used to implement devirtualized oop closure dispatching.
          //  - Various type checking in the JVM
          0xc:const KlassKind _kind;
          0x10:AccessFlags _access_flags;
          0x18:KlassFlags _misc_flags;
          0x20:juint _super_check_offset;
          0x28:Symbol * _name;
          0x30:Klass*      _secondary_super_cache;
          0x38:Array<Klass*>* _secondary_supers;
          0x40~0x78:Klass*      _primary_supers[_primary_super_limit]; //_primary_super_limit=8
          0x80:OopHandle   _java_mirror;
          0x88:Klass*      _super;
          0x90:Klass* volatile _subklass;
          0x98:Klass* volatile _next_sibling;
          0xa0:Klass*      _next_link;
          0xa8:ClassLoaderData* _class_loader_data;
          0xb0:markWord _prototype_header;   // Used to initialize objects' header
          0xb8:uintx    _secondary_supers_bitmap;
          0xc0:uint8_t  _hash_slot;
          0xc2:s2 _shared_class_path_index;
          0xc4:u2 _shared_class_flags;
          0xc8:int _vtable_len;
          ...
    } // 存在虚函数
    */

    /* InstanceKlass
    class InstanceKlass: public Klass {
        protected:
            Annotations*    _annotations;
            PackageEntry*   _package_entry;
            ObjArrayKlass* volatile _array_klasses;
            ConstantPool* _constants;
            Array<jushort>* _inner_classes;
            Array<jushort>* _nest_members;
            InstanceKlass* _nest_host;
            Array<jushort>* _permitted_subclasses;
            Array<RecordComponent*>* _record_components;
            const char*     _source_debug_extension;
            int             _nonstatic_field_size;
            int             _static_field_size;       // number words used by static fields (oop and non-oop) in this klass
            int             _nonstatic_oop_map_size;  // size in words of nonstatic oop map blocks
            int             _itable_len;              // length of Java itable (in words)
            u2              _nest_host_index;
            u2              _this_class_index;        // constant pool entry
            u2              _static_oop_field_count;  // number of static oop fields in this klass
            volatile u2     _idnum_allocated_count;   // JNI/JVMTI: increments with the addition of methods, old ids don't change
            volatile ClassState _init_state;          // state of class
            u1              _reference_type;                // reference type
            InstanceKlassFlags _misc_flags;
            JavaThread* volatile _init_thread;        // Pointer to current thread doing initialization (to handle recursive initialization)
            OopMapCache*    volatile _oop_map_cache;   // OopMapCache for all methods in the klass (allocated lazily)
            JNIid*          _jni_ids;                  // First JNI identifier for static fields in this class
            jmethodID* volatile _methods_jmethod_ids;  // jmethodIDs corresponding to method_idnum, or null if none
            nmethodBucket*  volatile _dep_context;     // packed DependencyContext structure
            uint64_t        volatile _dep_context_last_cleaned;
            nmethod*        _osr_nmethods_head;    // Head of list of on-stack replacement nmethods for this class
          #if INCLUDE_JVMTI
            BreakpointInfo* _breakpoints;          // bpt lists, managed by Method*
            InstanceKlass* _previous_versions;
            JvmtiCachedClassFileData* _cached_class_file;
          #endif

          #if INCLUDE_JVMTI
            JvmtiCachedClassFieldMap* _jvmti_cached_class_field_map;  // JVMTI: used during heap iteration
          #endif

            NOT_PRODUCT(int _verify_count;)  // to avoid redundant verifies
            NOT_PRODUCT(volatile int _shared_class_load_count;) // ensure a shared class is loaded only once

            // Method array.
            Array<Method*>* _methods;
            Array<Method*>* _default_methods;
            Array<InstanceKlass*>* _local_interfaces;
            Array<InstanceKlass*>* _transitive_interfaces;
            Array<int>*     _method_ordering;
            Array<int>*     _default_vtable_indices;

            Array<u1>*          _fieldinfo_stream;
            Array<u1>*          _fieldinfo_search_table;
            Array<FieldStatus>* _fields_status;
    */

    // 在 C++-ABI 中 每一个带虚函数的类都有一个隐藏字段 vptr(8B on 64-bit 4B on 32-bit)，存放在对象内存的最前面
    // 所以Klass对象的内存分布是 LSB->MSB: vptr(8B) _layout_helper(4B) _kind(2B) padding(对齐到4B)
    val LhKidOff = 8

    val VTableLenOff = 160 //@todo 200?
    val NonstaticOopMapSizeOff = 296
    val ITableLenOff = 300

    /*
    InstanceKlass::header_size = sizeof(InstanceKlass)
    wordSize = sizeof(char*)
    inline ByteSize Klass::vtable_start_offset() {
        return in_ByteSize(InstanceKlass::header_size() * wordSize);
    }
    */
    val VTableOff = 464

    val StaticFieldOff = 184

    /*
    The markWord describes the header of an object.
    Bit-format of an object header (most significant first, big endian layout below):
    32 bits:
    -------- hash:25 ------------>| age:4  self-fwd:1  lock:2 (normal object)

    64 bits:
    ------- unused:22 hash:31 -->| unused_gap:4  age:4  self-fwd:1  lock:2 (normal object)

    64 bits (with compact headers):
    -------------------------------
    klass:22  hash:31 -->| unused_gap:4  age:4  self-fwd:1  lock:2 (normal object)
     */
    val ageOff = 3
    val ageWidth = 4

    val InstanceKlassID = 0
    val InstanceRefKlassID = 1
    val InstanceMirrorKlassID = 2
    val InstanceClassLoaderKlassID = 3
    val InstanceStackChunkKlassKind = 4 // @todo 没有做 栈块 的GC
    val TypeArrayKlassID = 5 // _layout_helper-tag: C0 对于基本类型数组 数组元素的值是值类型 在内存中就是直接存放的数值 没有引用字段 不需要遍历; GC只需要关注并复制对象头以及内容区域的字节即可
    val ObjArrayKlassID = 6  // _layout_helper-tag: 80 对于对象数组 需要进行遍历单元 得到引用字段
}
