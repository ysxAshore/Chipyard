package gc_acc

import chisel3._
import chisel3.util._

/* TaskStack
@func: 在配置指令时给定 软件栈的栈顶和栈底地址 目前是需要配置两次
*/
class TaskStack extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    val push = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val pop = DecoupledIO(UInt(gcDataWidth.W))

    // 提前预取栈顶任务 但此时 并不出栈
    val preFetch = DecoupledIO(UInt(gcDataWidth.W))

    // 内存中的软件栈
    val memStack = new Bundle{
      val top = Input(UInt(addrWidth.W))
      val bottom = Input(UInt(addrWidth.W))
    }

    // 溢出时 对软件栈的 写地址 and 写数据
    val spillOut = DecoupledIO(new Bundle{
      val addr = UInt(addrWidth.W)
      val data = UInt(gcDataWidth.W)
    })

    val readBack = DecoupledIO(UInt(addrWidth.W))

    val req_id = Input(UInt(reqNum.W))

    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))

    val config = Input(UInt(3.W))  // 一共几条指令，第一条指令配置栈顶，第二条指令配置栈底 第三条配置复制地址 第四条配置启动
    val taskDone = Output(Bool())

    val spillCount = Output(UInt(addrWidth.W))
  })

  // 硬件栈 是一个循环队列
  val data = RegInit(VecInit(Seq.fill(TaskEntry)(0.U(gcDataWidth.W))))
  val top = RegInit(0.U(log2Ceil(TaskEntry).W))
  val bottom = RegInit(0.U(log2Ceil(TaskEntry).W))
  val req_id = RegInit(0.U(reqNum.W))

  // 软件栈
  val memTop = RegInit(0.U(addrWidth.W))
  val memBottom = RegInit(0.U(addrWidth.W))

  // 已发出有效读请求
  val read_req_valid = RegInit(true.B)

  // 表示溢出个数
  val spillCount = RegInit(0.U(addrWidth.W))

  io.spillCount := spillCount

  // @change: 可以改为配置一次 因为config中是做了两个cfgData的
  when(io.config === ConfigStackTop.U) { // 配置栈
    memTop := io.memStack.top
  }.elsewhen(io.config === ConfigStackBottom.U) {
    memBottom := io.memStack.bottom
  }

  // 配置GC启动 且 软件栈、硬件栈都已空
  io.taskDone := (io.config > ConfigToSpace.U) && top === bottom && memTop === memBottom

  // push和pop都是针对 top 的操作
  // push——从trace单元遍历得到一个引用字段入硬件栈: ready的充要条件是 已配置软件栈栈底 且 硬件栈不满
  io.push.ready := (io.config > ConfigStackBottom.U) && !(((top > bottom) && ((top - bottom) === (TaskEntry.U - 1.U))) || ((bottom > top) && ((bottom - top) === 1.U)))

  // pop——从硬件栈中弹出一个任务: valid的充要条件是 硬件栈不空
  io.pop.valid := bottom =/= top
  io.pop.bits := data(top)

  when(io.push.fire) {
    when(top + 1.U === TaskEntry.U) {
      data(0.U) := io.push.bits
      top := 0.U
    }.otherwise {
      data(top + 1.U) := io.push.bits
      top := top + 1.U
    }
  }.elsewhen(io.pop.fire) {
    when(top === 0.U){
      top := TaskEntry.U - 1.U
    }.otherwise {
      top := top - 1.U
    }
  }

  // 预取但是不出栈 预取成功再出栈
  io.preFetch.valid := bottom =/= top
  io.preFetch.bits := data(top)

  // 溢出: 当硬件任务栈中的任务数超出溢出阈值spillNeed 会触发溢出
  io.spillOut.valid := (top > bottom && (top - bottom) >= spillNeed.U) || ((bottom > top) && (bottom - top) <= (TaskEntry.U - spillNeed.U))  // @todo:why? (bottom - top + spillNeed.U) <= TaskEntry.U 它算不对

  // 溢出从 硬件栈 栈底 取数据 存入 软件栈 栈顶
  // 这里才用到了bottom
  io.spillOut.bits.addr := memTop
  io.spillOut.bits.data := Mux(bottom + 1.U === TaskEntry.U, data(0.U), data(bottom + 1.U))

  // 溢出 优先级 高于 回填
  when(io.spillOut.fire) {
    when(bottom + 1.U === TaskEntry.U) {
      bottom := 0.U
    }.otherwise {
      bottom := bottom + 1.U
    }
    memTop := memTop + 8.U
    read_req_valid := false.B
    spillCount := spillCount + 1.U
    printf(p"spill: ${io.spillOut.bits.data}\n")
  }.elsewhen(io.readData.valid && io.readData.bits.id === req_id && read_req_valid) {

    // 避免和push一块填充时导致的溢出 -> 至少保证有 两项 空余
    when(!(io.push.fire && ((top >= bottom && ((top - bottom) === (TaskEntry.U - 2.U))) || (bottom > top && (bottom - top === 2.U))))) {
      // 回填: 从 软件栈 栈顶 读任务 写到 硬件栈 栈底
      data(bottom) := io.readData.bits.data
      when(bottom  === 0.U) {
        bottom := TaskEntry.U - 1.U
      }.otherwise {
        bottom := bottom - 1.U
      }
      // 栈顶递减
      memTop := memTop - 8.U
    }
    read_req_valid := false.B
  }.elsewhen(io.readBack.fire) {
    //记录readBack data的req_id 用于之后 数据匹配
    req_id := io.req_id
    read_req_valid := true.B
  }

  // 发出回填请求: 没有已发出但是没有响应的回填请求 且 软件任务栈不空 且 硬件任务栈 中的任务数 少于回填阈值readNeed
  // 最后的|| 是 考虑上刚配置时的情况
  io.readBack.valid := ((io.config > ConfigStackBottom.U && !read_req_valid ) && (memTop =/= memBottom) && ((top >= bottom && (top - bottom) <= readNeed.U) || bottom > top && (bottom - top) >= (TaskEntry.U - readNeed.U))) || (io.config === ConfigStackBottom.U && (memTop =/= io.memStack.bottom))
  // 回填从 软件栈 栈顶 取任务 将任务存到 硬件栈 栈底
  io.readBack.bits := memTop - 8.U

}
