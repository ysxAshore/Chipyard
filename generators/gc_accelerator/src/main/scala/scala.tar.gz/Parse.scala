package gc_acc

import chisel3._
import chisel3.util._

class Parse extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{

    val fetch2Parse = Flipped(DecoupledIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val objAddr = UInt(gcDataWidth.W)
      val markWord = UInt(gcDataWidth.W)
      val klass = UInt(gcDataWidth.W)
    }))

    val parse2Copy = DecoupledIO(new Bundle{
      val objAddr = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
      val size = UInt(gcDataWidth.W)  // Word, 64bit
    })

    // 更新引用
    val parse2Remap = DecoupledIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
    })

    // 遍历 对象的引用字段
    val parse2Trace = DecoupledIO(new Bundle{
      val objAddr = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
      val klass = UInt(gcDataWidth.W)
      val klassID = UInt(IntWidth.W) // 5种
      val arrayLen = UInt(IntWidth.W) // 数组长度是32位+padding吗？直接传低32位？
    })

    // 比如 基础数组 以及 长度为0 的数组
    // 只有对象头，没有字段，写完对象头，直接通知 取指单元 取新任务
    val parseNoField = Output(Bool())

    val readMem = DecoupledIO(UInt(gcDataWidth.W))
    val writeMem = DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    })

    val req_id = Input(UInt(reqNum.W))

    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))

    val config = Input(UInt(3.W))

    // 配置阶段 给的复制对象目标区域的 起始地址
    val toSpace = Input(UInt(gcDataWidth.W))
  })

  val newObjAddr = RegInit(0.U(gcDataWidth.W))

  val task = RegInit(0.U(gcDataWidth.W))
  // 用一个task_valid有效与否 标志 task/objAddr/markWord/klass 的有效与否
  val task_valid = RegInit(false.B)

  val objAddr = RegInit(0.U(gcDataWidth.W))
  val markWord = RegInit(0.U(gcDataWidth.W))
  val klass = RegInit(0.U(gcDataWidth.W))

  val remap_valid = RegInit(false.B) // 是否已经发给 remap
  val copy_valid = RegInit(false.B)  // 是否已经发给 copy
  val trace_valid = RegInit(false.B) // 是否已经发给 trace
  val fetch_valid = RegInit(false.B) // 是否已经发给 fetch parseNofield

  val markWord_wreq = RegInit(0.U(gcDataWidth.W))
  val markWord_wreq_valid = RegInit(false.B)
  val oldMarkWord_wreq = RegInit(0.U(gcDataWidth.W))
  val oldMarkWord_wreq_valid = RegInit(false.B)
  val klass_wreq = RegInit(0.U(gcDataWidth.W))
  val klass_wreq_valid = RegInit(false.B)

  val lh_kid = RegInit(0.U(gcDataWidth.W))
  val lh_kid_valid = RegInit(false.B)
  val lh_kid_req_addr = RegInit(0.U(gcDataWidth.W))
  val lh_kid_req_id = RegInit(0.U(reqNum.W))
  val lh_kid_req_valid = RegInit(false.B)

  val arrayLenL = RegInit(0.U(gcDataWidth.W))
  val arrayLenL_valid = RegInit(false.B)
  val arrayLenL_req_addr = RegInit(0.U(gcDataWidth.W))
  val arrayLenL_req_id = RegInit(0.U(reqNum.W))
  val arrayLenL_req_valid = RegInit(false.B)
  val arrayLenL_wreq_addr = RegInit(0.U(gcDataWidth.W))
  val arrayLenL_wreq_valid = RegInit(false.B)

  val mirror_sizeL = RegInit(0.U(gcDataWidth.W))
  val mirror_sizeL_valid = RegInit(false.B)
  val mirror_sizeL_req_addr = RegInit(0.U(gcDataWidth.W))
  val mirror_sizeL_req_id = RegInit(0.U(reqNum.W))
  val mirror_sizeL_req_valid = RegInit(false.B)

  val age = RegInit(0.U(ageWidth.W))

  val lh = lh_kid(31,0)    // 低4B 是 _layout_helper
  val kid = lh_kid(63, 32) // 高2B加对齐的2B 是 _kind

  // 对于数组对象 数组的大小 = 数组的长度 * 每个元素的大小 + 数组头大小
  // lh(7,0)--log2(esz) lh(23,16)--hsz
  val array_size = (arrayLenL(31,0).asUInt << lh(7,0)).asUInt + lh(23,16).asUInt

  // 将以1B为单位变为以8B为单位 因为读写一次都是8B的带宽
  val array_size_align = Mux(array_size(2,0).asUInt === 0.U, array_size.asUInt >> 3.U, (array_size.asUInt >> 3.U).asUInt + 1.U)  // 对齐这样处理？

  // 普通对象 lh就是 instance size 是以1B为单位的 这里将其变为以8B为单位 因为读写一次都是8B的带宽
  val instance_size = lh >> 3.U

  // 镜像Klass对象 单独读取OopSize @todo 为什么不是mirror_sizeL(31,0)
  val mirror_size = mirror_sizeL(63,32)

  // 最后得到的对象size(8B单位):
  val size = Mux(kid === InstanceMirrorKlassID.U, mirror_size, Mux(lh(31) === 1.U, array_size_align, instance_size))

  // 对象头是否已经写完 在 引用字段有效 且 已经得到了layout_helper和klass_id 之后判断写情况
  // 写顺序是: OldMarkWord -> MarkWord -> Klass -> 数组长度
  // 因此 如果是数组, 那写完就意味着 已经发出 写数组的请求 或者 在 Klass写请求 发出之后 又发出了写请求
  //     否则， 写完意味着 已经发出Klass的写请求 或者 在MarkWord写请求 发出以后 又发出了写请求
  val head_valid = task_valid && lh_kid_valid && Mux(lh(31) === 1.U, arrayLenL_wreq_valid || (io.writeMem.fire && klass_wreq_valid), klass_wreq_valid || (io.writeMem.fire && markWord_wreq_valid))

  // 已标记任务 取指阶段的 最后一拍 只需要更新引用即可
  val markedEnd = io.parse2Remap.fire && ((!io.fetch2Parse.fire && markWord(1,0) === Mark.U) || (io.fetch2Parse.fire && io.fetch2Parse.bits.markWord(1,0) === Mark.U))

  // 未标记任务 取指阶段的 的最后一拍: 对象头写完 且 遍历、复制、更新引用都已经发出了
  //    没有引用字段: 对象头写完 且 已发出或即将发出 更新引用请求 且 没有引用字段或者即将没有引用字段
  //    存在引用字段: 对象头写完 且 已发出或即将发出 更新引用请求 且 已发出或即将发出 复制请求 且 已发出或者即将发出 遍历请求
  val unmarkEnd = ((fetch_valid || io.parseNoField) || ((copy_valid || io.parse2Copy.fire) && (trace_valid || io.parse2Trace.fire))) && (remap_valid || io.parse2Remap.fire) && head_valid

  // 目标地址是 连续 的 解析单元 内部 通过一个寄存器维护配置的初始目标地址
  when(io.config === ConfigToSpace.U) {
    newObjAddr := io.toSpace
  }.elsewhen(unmarkEnd) {  // 未标记任务结束的最后一拍更新地址  因为此时之后用到newObjAddr的单元均已发出请求
    newObjAddr := newObjAddr + (size << 3.U) // 因为之前的size是8B为单位的 这里 因为地址是1B为单位 所以 size << 3

    // debug 信息 每填充完64K 输出一次
    val nextObjAddr = newObjAddr.asUInt + (size.asUInt << 3.U).asUInt
    when(nextObjAddr(63, 16) > newObjAddr(63, 16).asUInt) {
      printf(p"nextObjAddr: ${nextObjAddr}\n")
    }
  }

  // 解析单元 当前没有在处理引用字段 即可接受 取指阶段发来的新请求
  io.fetch2Parse.ready := !task_valid

  // 接收 取指单元 送来的信息
  when(io.fetch2Parse.fire) {
    task := io.fetch2Parse.bits.task
    objAddr := io.fetch2Parse.bits.objAddr
    markWord := io.fetch2Parse.bits.markWord
    klass := io.fetch2Parse.bits.klass

    age := io.fetch2Parse.bits.markWord(ageOff + ageWidth - 1.U, ageOff)

    // 从 klass对象地址 上读取 _layout_helper 和 _kind
    lh_kid_req_addr := io.fetch2Parse.bits.klass + LhKidOff.U

    // 从 对象地址 + 数组长度偏移 上读取
    arrayLenL_req_addr := io.fetch2Parse.bits.objAddr + ArrayLenOff.U

    // 从 对象地址 + Mirror对象大小偏移 上读取
    mirror_sizeL_req_addr := io.fetch2Parse.bits.objAddr + OopSizeOff.U

    // 重映射单元 更新引用 所需要的复制目的地址 在fetch2Parse.fire时即可以得到 因此此时可以启动 重映射单元
    io.parse2Remap.valid := true.B
    io.parse2Remap.bits.task := io.fetch2Parse.bits.task

    // 如果已标记的话 目标地址是在markWord的高62位+2'b0
    // 如果没有标记的话 目标地址由解析单元计算的newObjAddr提供
    io.parse2Remap.bits.newObjAddr := Mux(io.fetch2Parse.bits.markWord(1,0) === Mark.U, Cat(io.fetch2Parse.bits.markWord(63, 2), 0.U(2.W)), newObjAddr)
  }.otherwise {
    // markWord最后两位为标记位
    // 11表示已标记，新地址就是markWord前62位+2位0
    // 未标记的新地址为newObjAddr，本轮将计算出下一轮的新地址，下一轮的新地址没算完也可以直接走，反正Copy没握手新数据不会进来
    // parse2Remap的valid和ready握手成功之后 才会更新remap_valid
    io.parse2Remap.valid := task_valid && !remap_valid
    io.parse2Remap.bits.task := task
    io.parse2Remap.bits.newObjAddr := Mux(markWord(1,0) === Mark.U, Cat(markWord(63, 2), 0.U(2.W)), newObjAddr)
  }

  // 这里的 size 都是 8B 为单位
  // 可以发往Copy的使能条件是: 当前模块的 引用字段有效 且 没有握手成功的copy请求 且 已经得到了layout_helper and klassid 且 对于数组元素 数组长度不为0 或者 对于 InstanceMirror 大小不为2(>2)(因为MarkWord+Klass*就是2B了) 或者对于实例对象 大小不为2 且 Copy和Trace都可以接受请求
  // 即 引用字段有效 且 之前没有握手过 且 之后的模块也都可以接受请求 且 已经得到了layout_helper and klassid 且 当前引用字段上的对象有字段
  io.parse2Copy.valid := task_valid && !copy_valid && lh_kid_valid && Mux(lh(31) === 1.U, arrayLenL_valid && arrayLenL(31,0) =/= 0.U, Mux(kid === InstanceMirrorKlassID.U, mirror_sizeL_valid && mirror_size =/= 2.U, instance_size.asUInt =/= 2.U)) && io.parse2Copy.ready && io.parse2Trace.ready
  io.parse2Copy.bits.objAddr := objAddr + Mux(lh(31) === 0.U, 16.U, 24.U)
  io.parse2Copy.bits.newObjAddr := newObjAddr + Mux(lh(31) === 0.U, 16.U, 24.U) // 24是比16多了一个ArrayLen
  io.parse2Copy.bits.size := Mux(lh(31) === 1.U, array_size_align.asUInt - 3.U, Mux(kid === InstanceMirrorKlassID.U, mirror_size - 2.U, instance_size.asUInt - 2.U)) // 以8B 为单位

  // 可以发往Trace的使能条件是: 当前模块的 引用字段有效 且 没有握手成功的copy请求 且 已经得到了layout_helper and klassid 且 对于数组元素 数组长度不为0 或者 对于 InstanceMirror 大小不为2(>2)(因为MarkWord+Klass*就是2B了) 或者对于实例对象 大小不为2 且 Copy和Trace都可以接受请求
  // 不用区分 基本类型数组和对象数组吗？ 基本类型数组不用遍历 -> 在 遍历阶段 根据kid处理了
  io.parse2Trace.valid := task_valid && !trace_valid && lh_kid_valid && Mux(lh(31) === 1.U, arrayLenL_valid && arrayLenL(31,0) =/= 0.U, Mux(kid === InstanceMirrorKlassID.U, mirror_sizeL_valid && mirror_size =/= 2.U, instance_size.asUInt =/= 2.U)) && io.parse2Copy.ready && io.parse2Trace.ready
  io.parse2Trace.bits.objAddr := objAddr
  io.parse2Trace.bits.newObjAddr := newObjAddr
  io.parse2Trace.bits.klass := klass
  io.parse2Trace.bits.klassID := kid
  io.parse2Trace.bits.arrayLen := arrayLenL(31,0)

  // 对象头最后一个写请求发出去后，下一拍才true，要不要再抢一拍？
  // 写完了就通知Fetch取数据，不用管Remap是否送走，反正如果Remap没结束，任务没结束，Fetch完成也是堵着
  // @todo:不用考虑 数组长度的写请求发不发出吗？ 是因为值为0 内存初始化为0？
  io.parseNoField := task_valid && !fetch_valid && lh_kid_valid && klass_wreq_valid && Mux(lh(31) === 1.U, arrayLenL_valid && arrayLenL(31,0) === 0.U && arrayLenL_wreq_valid, Mux(kid === InstanceMirrorKlassID.U, mirror_sizeL_valid && mirror_size === 2.U, instance_size === 2.U)) || markedEnd

  // 当从 取指单元 得到一个新任务时 如果该对象 没有被标记 那么发出读请求 读取 _layout_helper and _kind
  when(io.fetch2Parse.fire && io.fetch2Parse.bits.markWord(1,0) =/= Mark.U) {
    io.readMem.bits := io.fetch2Parse.bits.klass + LhKidOff.U
    io.readMem.valid := true.B
  }.elsewhen(task_valid && lh_kid_req_valid && !lh_kid_valid && io.readData.valid && io.readData.bits.id === lh_kid_req_id && io.readData.bits.data(63,32) === InstanceMirrorKlassID.U) { // 镜像类
    // 读到lh_kid 对于镜像类 需要再读取 mirror_size/Oop_Size
    io.readMem.valid := true.B
    io.readMem.bits := mirror_sizeL_req_addr
  }.elsewhen(task_valid && lh_kid_req_valid && !lh_kid_valid && io.readData.valid && io.readData.bits.id === lh_kid_req_id && io.readData.bits.data(31) === 1.U) { //layout为负数 表示数组 这里的_kind包括了 TypeArrayKlassKind ObjArrayKlassKind
    // 读返回lh_kid 对于数组对象 需要读取数组长度 -> 为了得到拷贝多少字节
    io.readMem.valid := true.B
    io.readMem.bits := arrayLenL_req_addr
  }.otherwise {
    io.readMem.valid := task_valid && (!lh_kid_req_valid || (lh_kid_valid && kid === InstanceMirrorKlassID.U && !mirror_sizeL_req_valid) || (lh_kid_valid && lh(31) === 1.U && !arrayLenL_req_valid))
    io.readMem.bits := Mux(!lh_kid_req_valid, lh_kid_req_addr, Mux(lh_kid_valid && kid === InstanceMirrorKlassID.U, mirror_sizeL_req_addr, arrayLenL_req_addr))
  }

  // 请求握手成功后 设置 req_valid 和 req_id
  when(io.readMem.fire) {
    when(!lh_kid_req_valid) {
      lh_kid_req_id := io.req_id
      lh_kid_req_valid := true.B
    }.elsewhen(lh_kid_valid && kid === InstanceMirrorKlassID.U || io.readData.valid && io.readData.bits.id === lh_kid_req_id && io.readData.bits.data(63,32) === InstanceMirrorKlassID.U) {
      mirror_sizeL_req_id := io.req_id
      mirror_sizeL_req_valid := true.B
    }.otherwise {
      arrayLenL_req_id := io.req_id
      arrayLenL_req_valid := true.B
    }
  }.elsewhen(unmarkEnd) {
    // 已经都发出去了 可以复位
    lh_kid_req_valid := false.B
    mirror_sizeL_req_valid := false.B
    arrayLenL_req_valid := false.B
  }

  when(io.readData.valid && lh_kid_req_valid && io.readData.bits.id === lh_kid_req_id && !lh_kid_valid) {
    lh_kid := io.readData.bits.data
    lh_kid_valid := true.B
  }.elsewhen(io.readData.valid && arrayLenL_req_valid && io.readData.bits.id === arrayLenL_req_id && !arrayLenL_valid) {
    arrayLenL := io.readData.bits.data
    arrayLenL_valid := true.B
  }.elsewhen(io.readData.valid && mirror_sizeL_req_valid && io.readData.bits.id === mirror_sizeL_req_id && !mirror_sizeL_valid) {
    mirror_sizeL := io.readData.bits.data
    mirror_sizeL_valid := true.B
  }.elsewhen(unmarkEnd) {
    lh_kid_valid := false.B
    mirror_sizeL_valid := false.B
    arrayLenL_valid := false.B
  }

  // 写顺序: OldMarkWord -> MarkWord -> Klass -> 数组长度
  // OldMarkWord: 写标记位 [1:0] = Mark 写新地址 [63:2] = newObjAddr(63,2)
  // MarkWord :  MarkWord 这里要处理age
  //             age+1 如果age大于15 这个的tospace就不再是原来的tospace了
  // Klass : klass
  // 数组长度: ArrayLen
  io.writeMem.valid := task_valid && (!oldMarkWord_wreq_valid || !markWord_wreq_valid || !klass_wreq_valid || (lh_kid_valid && (lh(31) === 1.U && arrayLenL_valid &&  !arrayLenL_wreq_valid)))
  io.writeMem.bits.addr := Mux(!oldMarkWord_wreq_valid, objAddr + MarkWordOff.U, Mux(!markWord_wreq_valid, newObjAddr + MarkWordOff.U, Mux(!klass_wreq_valid, newObjAddr + KlassOff.U, newObjAddr + ArrayLenOff.U)))
  io.writeMem.bits.data := Mux(!oldMarkWord_wreq_valid, Cat(newObjAddr(63,2), 3.U(2.W)), Mux(!markWord_wreq_valid, markWord, Mux(!klass_wreq_valid, klass, arrayLenL)))

  when(io.writeMem.fire && !oldMarkWord_wreq_valid) {
    oldMarkWord_wreq_valid := true.B
  }.elsewhen(io.writeMem.fire && !markWord_wreq_valid) {
    markWord_wreq_valid := true.B
  }.elsewhen(io.writeMem.fire && !klass_wreq_valid && !unmarkEnd) {
    klass_wreq_valid := true.B
  }.elsewhen(io.writeMem.fire && !arrayLenL_wreq_valid && !unmarkEnd) {
    arrayLenL_wreq_valid := true.B
  }.elsewhen(unmarkEnd) {
    markWord_wreq_valid := false.B
    klass_wreq_valid := false.B
    oldMarkWord_wreq_valid := false.B
    arrayLenL_wreq_valid := false.B
  }

  // 取指模块送来的是一个未标记的任务 或者 更新引用模块 并不能接收新任务
  // Parse和Remap 是并行的
  when(io.fetch2Parse.fire && (io.fetch2Parse.bits.markWord(1,0) =/= Mark.U || !io.parse2Remap.ready)){
    // 如果是前者 则需要使能task_valid 后者则继续保持
    task_valid := true.B

    // 如果是前者 则同时需要设置remap_valid -> Parse和Remap是并行的
    when(io.parse2Remap.ready) {
      remap_valid := true.B
    }
  }.elsewhen(markedEnd || unmarkEnd) {
    // 解析单元 任务执行完毕 复位
    task_valid := false.B
    when(fetch_valid) {
      fetch_valid := false.B
    }
    when(remap_valid) {
      remap_valid := false.B
    }
    when(copy_valid) {
      copy_valid := false.B
    }
    when(trace_valid) {
      trace_valid := false.B
    }
  }.otherwise {
    when(io.parse2Remap.fire) {
      remap_valid := true.B
    }
    when(io.parse2Copy.fire) {
      copy_valid := true.B
    }
    when(io.parse2Trace.fire) {
      trace_valid := true.B
    }
    when(io.parseNoField) {
      fetch_valid := true.B
    }
  }

}

