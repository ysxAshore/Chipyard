package gc_acc

import chisel3._
import chisel3.util._

class Trace extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    val parse2Trace = Flipped(DecoupledIO(new Bundle{
      val objAddr = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
      val klass = UInt(gcDataWidth.W)
      val klassID = UInt(IntWidth.W)
      val arrayLen = UInt(IntWidth.W)
    }))

    val trace2Stack = DecoupledIO(UInt(gcDataWidth.W))

    // 遍历单元 的 前递机制
    // 将 最后一个 非空的 引用字段地址  和相应的 对象地址 前递给取任务单元 无需入栈再去取
    val trace2Fetch = ValidIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val objAddr = UInt(gcDataWidth.W)
    })

    // 通知 取指单元 该引用字段的子对象的没有引用对象
    val traceNoRef = Output(Bool())

    // 复制单元 通知 遍历单元 复制完毕
    val copyDone = Input(Bool())

    val readMem = DecoupledIO(UInt(gcDataWidth.W))
    val req_id = Input(UInt(reqNum.W))
    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))

    // debug info
    val testRefCount = Output(UInt(gcDataWidth.W))
    val traceCount = Output(UInt(gcDataWidth.W))
    val traceForwardCount = Output(UInt(gcDataWidth.W))
  })

  val task_valid = RegInit(false.B)

  val objAddr = RegInit(0.U(gcDataWidth.W))
  val newObjAddr = RegInit(0.U(gcDataWidth.W))
  val klass = RegInit(0.U(gcDataWidth.W))
  val klassID = RegInit(0.U(IntWidth.W))

  val copyDone = RegInit(false.B)

  val vtableLen = RegInit(0.U(IntWidth.W))
  val vtableLenL_valid = RegInit(false.B)
  val vtableLenL_req_addr = RegInit(0.U(gcDataWidth.W))
  val vtableLenL_req_id = RegInit(0.U(reqNum.W))
  val vtableLenL_req_valid = RegInit(false.B)

  val itableLen = RegInit(0.U(IntWidth.W))
  val itableLenL_valid = RegInit(false.B)
  // 低位NonstaticOopMapSize，高位ITableLen
  val itableLenL_req_addr = RegInit(0.U(gcDataWidth.W))
  val itableLenL_req_id = RegInit(0.U(reqNum.W))
  val itableLenL_req_valid = RegInit(false.B)

  // NonStaticOopMap
  val oopMapCount = RegInit(0.U(IntWidth.W))
  val oopMapAddr = RegInit(0.U(gcDataWidth.W))

  // mirrorKlass进行静态字段遍历
  val staticRefIter_valid = RegInit(false.B)

  // StaticOop MirrorInstanceKlass需要请求
  val staticCount = RegInit(0.U(IntWidth.W))
  val staticCount_valid = RegInit(false.B)
  val staticCount_req_addr = RegInit(0.U(gcDataWidth.W))
  val staticCount_req_id = RegInit(0.U(reqNum.W))
  val staticCount_req_valid = RegInit(false.B)

  // 记录需要拷贝的引用字段个数
  // 对于对象数组 refCount就是 数组长度
  // 对于其他 refCount是每一个OopMap项 具有的引用字段个数
  val refCount = RegInit(0.U(IntWidth.W))
  // 本次读取 的对象引用字段 地址——获取objAddr
  val objRefOff = RegInit(0.U(IntWidth.W))

  // ref_req_id 记录的是 引用字段 的请求id
  // ref_off_data 是 引用字段地址
  // ref_data 是 引用字段保存的对象地址
  // 记录是为了 比较方便的 给topTask(ref_off_data(head)) topObj(ref_data(head))
  val ref_req_id = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(5.W))))
  val ref_off_data = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(gcDataWidth.W))))
  val ref_data = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(gcDataWidth.W))))
  val ref_data_valid = RegInit(VecInit(Seq.fill(CopyEntry)(false.B)))
  val ref_head = RegInit(0.U(log2Ceil(CopyEntry).W))
  val ref_tail = RegInit(0.U(log2Ceil(CopyEntry).W))


  // 遍历OopMap
  val map_req_id = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(5.W))))
  val map_data = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(gcDataWidth.W))))
  val map_data_valid = RegInit(VecInit(Seq.fill(CopyEntry)(false.B)))
  val map_head = RegInit(0.U(log2Ceil(CopyEntry).W))
  val map_tail = RegInit(0.U(log2Ceil(CopyEntry).W))

  // 传递给 取指单元 和 硬件栈 的 引用字段地址 和 对象地址
  val topTask = RegInit(0.U(gcDataWidth.W))
  val topTask_valid = RegInit(false.B)
  val topObj = RegInit(0.U(gcDataWidth.W))

  // debug相关 traceCount记录 遍历单元找到的子对象个数 traceForwardCount记录前递给 取指单元 的个数
  val traceCount = RegInit(0.U(gcDataWidth.W))
  val traceForwardCount = RegInit(0.U(gcDataWidth.W))

  io.traceCount := traceCount
  io.traceForwardCount := traceForwardCount

  // 遍历单元 工作结束
  // 当前引用字段有效 且 CopyDone工作结束
  // 对于对象数组 refCount=0 且 ref_tail==ref_head 全都遍历完毕
  // 对于非对象数组 : 非MirrorInstanceKlass 需要读取vtable_len itable_len 且 OopMap遍历完毕 且 refCount=0 且 ref_tail==ref_head 全都遍历完毕
  //                MirrorInstanceKlass 除了需要拷贝NonStaticOop 还需要拷贝StaticOop
  // @question:
  val traceIterDone = task_valid && copyDone && ((klassID =/= ObjArrayKlassID.U && vtableLenL_valid && itableLenL_valid && oopMapCount === 0.U && map_head === map_tail) || klassID === ObjArrayKlassID.U) && refCount === 0.U && ref_head === ref_tail && (klassID =/= InstanceMirrorKlassID.U || (klassID === InstanceMirrorKlassID.U && staticCount_valid && (staticCount === 0.U || staticCount =/= 0.U && staticRefIter_valid)))

  io.testRefCount := refCount

  // 只要 遍历单元 没有有效任务 -> 解析单元 就可以 发送数据 到 遍历单元
  io.parse2Trace.ready := !task_valid

  // 对于 基本类型数组 不需要 遍历
  when(io.parse2Trace.fire && !(io.parse2Trace.bits.klassID === TypeArrayKlassID.U)) {
    task_valid := true.B
  }.elsewhen(traceIterDone) {
    // 本次 引用字段对象 的 子对象 遍历完毕 复位
    task_valid := false.B
    vtableLenL_valid := false.B
    vtableLenL_req_valid := false.B
    itableLenL_valid := false.B
    itableLenL_req_valid := false.B
    staticCount_valid := false.B
    staticCount_req_valid := false.B
    staticRefIter_valid := false.B
  }

  when(io.parse2Trace.fire) {
    objAddr := io.parse2Trace.bits.objAddr
    newObjAddr := io.parse2Trace.bits.newObjAddr
    klass := io.parse2Trace.bits.klass
    klassID := io.parse2Trace.bits.klassID

    vtableLenL_req_addr := io.parse2Trace.bits.klass + VTableLenOff.U
    itableLenL_req_addr := io.parse2Trace.bits.klass + NonstaticOopMapSizeOff.U

    staticCount_req_addr := io.parse2Trace.bits.objAddr + StaticOopFieldCountOff.U
  }

  // 发送 访存请求
  when(io.parse2Trace.fire){
    // 对于非数组、非栈块对象 需要读取OopMap, 而确定OopMap地址 需要依靠Vtable_len  Itable_len等
    // 对于对象数组 则直接读取第一个对象判断即可
    when(io.parse2Trace.bits.klassID <= InstanceClassLoaderKlassID.U) {
      io.readMem.valid := true.B
      io.readMem.bits := io.parse2Trace.bits.klass + VTableLenOff.U
    }.elsewhen(io.parse2Trace.bits.klassID === ObjArrayKlassID.U) {
      io.readMem.valid := true.B
      io.readMem.bits := io.parse2Trace.bits.objAddr + ArrayElementOff.U
    }.otherwise{
      io.readMem.valid := false.B
      io.readMem.bits := 0.U
    }
  }.elsewhen(task_valid && klassID =/= TypeArrayKlassID.U) {
    // 读取顺序: vtableLenL -> itableLenL -> InstanceMirrorKlass需要读取staticCount -> 读取OopMap项 ->
    when(klassID =/= ObjArrayKlassID.U && !vtableLenL_req_valid) {
      io.readMem.valid := true.B
      io.readMem.bits := vtableLenL_req_addr
    }.elsewhen(klassID =/= ObjArrayKlassID.U && !itableLenL_req_valid) {
      io.readMem.valid := true.B
      io.readMem.bits := itableLenL_req_addr
    }.elsewhen(klassID === InstanceMirrorKlassID.U && !staticCount_req_valid) {
      io.readMem.valid := true.B
      io.readMem.bits := staticCount_req_addr
    }.elsewhen(klassID =/= ObjArrayKlassID.U && vtableLenL_valid && itableLenL_valid && (oopMapCount =/= 0.U && !((map_head - map_tail === 1.U) || ((map_tail - map_head + 1.U) === CopyEntry.U)))) {
      io.readMem.valid := true.B
      io.readMem.bits := oopMapAddr
    }.elsewhen(((klassID =/= ObjArrayKlassID.U && vtableLenL_valid && itableLenL_valid) || klassID === ObjArrayKlassID.U) && refCount =/= 0.U  && !((ref_head - ref_tail === 1.U) || ((ref_tail - ref_head + 1.U) === CopyEntry.U))) {
      io.readMem.valid := true.B
      io.readMem.bits := objAddr + objRefOff
    }.otherwise {
      io.readMem.valid := false.B
      io.readMem.bits := 0.U
    }
  }.otherwise {
    io.readMem.valid := false.B
    io.readMem.bits := 0.U
  }

  // 对象数组 正着查找
  // 非数组对象 倒着查找
  when(io.parse2Trace.fire) {
    when(io.parse2Trace.bits.klassID === ObjArrayKlassID.U) {
      when(io.readMem.fire) { //之前会先发一个 24
        objRefOff := ArrayElementOff + 8.U
        refCount := io.parse2Trace.bits.arrayLen - 1.U
      }.otherwise {
        objRefOff := ArrayElementOff.U
        refCount := io.parse2Trace.bits.arrayLen
      }
    }
  }.elsewhen(klassID === ObjArrayKlassID.U && io.readMem.fire) {
    objRefOff := objRefOff + 8.U
    refCount := refCount - 1.U
  }.elsewhen(klassID <= InstanceClassLoaderKlassID.U) { // 非数组对象 非栈块对象 非MirrorKlass 需要读取OopMap (0-63)(ref偏移,这块偏移有几个引用字段)
    when(vtableLenL_valid && itableLenL_valid && map_head =/= map_tail && map_data_valid(map_head) && refCount === 0.U) {
      // 倒序查找 计算最后一个ObjRef地址
      objRefOff := map_data(map_head)(31,0).asUInt + (map_data(map_head)(63,32).asUInt << 3.U).asUInt - 8.U
      refCount := map_data(map_head)(63,32)

      // 当前map_head已经访问过 更新迭代
      map_data_valid(map_head) := false.B
      when(map_head + 1.U === CopyEntry.U) {
        map_head := 0.U
      }.otherwise {
        map_head := map_head + 1.U
      }
    }.elsewhen(vtableLenL_valid && itableLenL_valid && refCount =/= 0.U && io.readMem.fire && !staticRefIter_valid) {
      objRefOff := objRefOff - 8.U
      refCount := refCount - 1.U
    }.elsewhen(klassID === InstanceMirrorKlassID.U && staticCount_valid) {
      // InstanceMirrorKlass对象 还需要遍历 Static Oop 正向遍历
      // 前提是 非静态Oop都已经遍历完毕
      when(vtableLenL_valid && itableLenL_valid && oopMapCount === 0.U && map_head === map_tail && refCount === 0.U && !staticRefIter_valid) {
        objRefOff := StaticFieldOff.U
        refCount := staticCount
        staticRefIter_valid := true.B
      }.elsewhen(io.readMem.fire && staticRefIter_valid) {
        objRefOff := objRefOff + 8.U
        refCount := refCount - 1.U
      }
    }
  }

  when(io.readMem.fire) {
    when((io.parse2Trace.fire && io.parse2Trace.bits.klassID === ObjArrayKlassID.U) || (!io.parse2Trace.fire && klassID === ObjArrayKlassID.U)) {
      ref_req_id(ref_tail) := io.req_id
      ref_off_data(ref_tail) := Mux(io.parse2Trace.fire, ArrayElementOff.U, objRefOff)
      when(ref_tail + 1.U === CopyEntry.U) {
        ref_tail := 0.U
      }.otherwise {
        ref_tail := ref_tail + 1.U
      }
    }.elsewhen(!vtableLenL_req_valid) {
      vtableLenL_req_id := io.req_id
      vtableLenL_req_valid := true.B
    }.elsewhen(!itableLenL_req_valid) {
      itableLenL_req_id := io.req_id
      itableLenL_req_valid := true.B
    }.elsewhen(klassID === InstanceMirrorKlassID.U && !staticCount_req_valid) {
      staticCount_req_id := io.req_id
      staticCount_req_valid := true.B
    }.elsewhen(vtableLenL_valid && itableLenL_valid && (oopMapCount =/= 0.U && !((map_head - map_tail === 1.U) || ((map_tail - map_head + 1.U) === CopyEntry.U)))) {
      map_req_id(map_tail) := io.req_id
      when(map_tail + 1.U === CopyEntry.U) {
        map_tail := 0.U
      }.otherwise {
        map_tail := map_tail + 1.U
      }
    }.elsewhen(vtableLenL_valid && itableLenL_valid && refCount =/= 0.U  && !((ref_head - ref_tail === 1.U) || ((ref_tail - ref_head + 1.U) === CopyEntry.U))) {
      ref_req_id(ref_tail) := io.req_id
      ref_off_data(ref_tail) := objRefOff
      when(ref_tail + 1.U === CopyEntry.U) {
        ref_tail := 0.U
      }.otherwise {
        ref_tail := ref_tail + 1.U
      }
    }
  }

  when(task_valid && io.readData.valid && (vtableLenL_req_valid && !vtableLenL_valid && vtableLenL_req_id === io.readData.bits.id && itableLenL_valid) || (itableLenL_req_valid && !itableLenL_valid && itableLenL_req_id === io.readData.bits.id && vtableLenL_valid)) {
    oopMapAddr := klass + VTableOff.U + ((Mux(vtableLenL_valid, vtableLen, io.readData.bits.data(31,0)) + Mux(itableLenL_valid, (itableLen + oopMapCount), (io.readData.bits.data(63,32) + (io.readData.bits.data(31,0))))) << 3.U).asUInt - 8.U
  }.elsewhen(io.readMem.fire && vtableLenL_valid && itableLenL_valid && (oopMapCount =/= 0.U && !((map_head - map_tail === 1.U) || ((map_tail - map_head + 1.U) === CopyEntry.U))) && (klassID =/= InstanceMirrorKlassID.U || (klassID === InstanceMirrorKlassID.U && staticCount_req_valid))) {
    oopMapAddr := oopMapAddr - 8.U
    oopMapCount := oopMapCount - 1.U
  }

  when(task_valid && io.readData.valid) {
    when(vtableLenL_req_valid && !vtableLenL_valid && vtableLenL_req_id === io.readData.bits.id) {
      vtableLen := io.readData.bits.data(31,0)
      vtableLenL_valid := true.B
    }.elsewhen(itableLenL_req_valid && !itableLenL_valid && itableLenL_req_id === io.readData.bits.id) {
      itableLen := io.readData.bits.data(63,32)
      oopMapCount := io.readData.bits.data(31,0)
      itableLenL_valid := true.B
    }.elsewhen(staticCount_req_valid && !staticCount_valid && staticCount_req_id === io.readData.bits.id) {
      staticCount := io.readData.bits.data(31,0)
      staticCount_valid := true.B
    }.otherwise{
      for(i <- 0 until CopyEntry) {
        when(map_data_valid(i) =/= true.B && map_req_id(i) === io.readData.bits.id && ((i.U >= map_head && i.U < map_tail) || (map_tail < map_head && (i.U < map_tail || i.U >= map_head)))) {
          map_data_valid(i) := true.B
          map_data(i) := io.readData.bits.data
        }.elsewhen(ref_data_valid(i) =/= true.B && ref_req_id(i) === io.readData.bits.id && ((i.U >= ref_head && i.U < ref_tail) || (ref_tail < ref_head && (i.U < ref_tail || i.U >= ref_head)))) {
          ref_data_valid(i) := true.B
          ref_data(i) := io.readData.bits.data
        }
      }
    }
  }

  when(task_valid && io.copyDone) {
    copyDone := true.B
  }.elsewhen(traceIterDone) {
    copyDone := false.B
  }

  // 可以考虑把引用的对象直接给Fetch模块，就不需要等copyDone了，省时间且给Fetch省一次访存，但是可能需要大改；暂时先把最后一个task给Fetch模块
  io.trace2Fetch.valid := traceIterDone && topTask_valid
  io.trace2Fetch.bits.task := topTask
  io.trace2Fetch.bits.objAddr := topObj

  when(io.trace2Fetch.valid) {
    traceForwardCount := traceForwardCount + 1.U
  }

  // 遍历过程中有新的有效的数据时，将旧数据入栈
  io.trace2Stack.valid := task_valid && topTask_valid && ref_head =/= ref_tail && ref_data_valid(ref_head) && ref_data(ref_head) =/= 0.U
  io.trace2Stack.bits := topTask

  when(io.trace2Stack.fire) {
    traceCount := traceCount + 1.U
  }

  when(ref_head =/= ref_tail && ref_data_valid(ref_head)) {
    when(ref_data(ref_head) =/= 0.U) {
      when(!topTask_valid || io.trace2Stack.fire) {
        topTask := newObjAddr + ref_off_data(ref_head)
        topObj := ref_data(ref_head)
        ref_data_valid(ref_head) := false.B
        when(!topTask_valid) {
          topTask_valid := true.B
        }
        when(ref_head + 1.U === CopyEntry.U) {
          ref_head := 0.U
        }.otherwise {
          ref_head := ref_head + 1.U
        }
      }
    }.otherwise {
      ref_data_valid(ref_head) := false.B
      when(ref_head + 1.U === CopyEntry.U) {
        ref_head := 0.U
      }.otherwise {
        ref_head := ref_head + 1.U
      }
    }
  }.elsewhen(traceIterDone && topTask_valid) {
    topTask_valid := false.B
  }

  // Ref类型先按正常类型处理，额外的引用处理先不管
  io.traceNoRef := (io.parse2Trace.fire && (io.parse2Trace.bits.klassID === TypeArrayKlassID.U)) || (traceIterDone && !topTask_valid)

}
