package gc_acc

import chisel3._
import chisel3.util._

class Copy extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    val parse2Copy = Flipped(DecoupledIO(new Bundle{
      val objAddr = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
      val size = UInt(gcDataWidth.W)
    }))

    //  通知Trace模块Copy结束
    val copyDone = Output(Bool())
    
    val readMem = DecoupledIO(UInt(gcDataWidth.W))
    val writeMem = DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    })

    val req_id = Input(UInt(reqNum.W))

    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))
  })

  val objAddr = RegInit(0.U(gcDataWidth.W))
  val newObjAddr = RegInit(0.U(gcDataWidth.W))
  val size = RegInit(0.U(gcDataWidth.W))

  val task_valid = RegInit(false.B)

  // id 和 data 都是 CopyEntry 项的循环队列
  // 当每一次 readMem请求 握手成功 以后 req_id(tail) 填入 请求id
  // 当readData回来后 遍历data和data_valid, 找到一个req_id(i) == readData.id 且 data_valid(i) = false的 填入 data(i) 和 data_valid(i)=true
  // 写时 使用head从data_valid(head) data(head)取
  // 这样 两个都是从0 记录开始的 最后复制完成时 head==tail
  val req_id = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(5.W))))
  val data = RegInit(VecInit(Seq.fill(CopyEntry)(0.U(gcDataWidth.W))))
  val data_valid = RegInit(VecInit(Seq.fill(CopyEntry)(false.B)))
  val head = RegInit(0.U(log2Ceil(CopyEntry).W))
  val tail = RegInit(0.U(log2Ceil(CopyEntry).W))

  // 复制单元 任务无效 时 可以接收新任务
  io.parse2Copy.ready := !task_valid

  io.copyDone := task_valid && size === 0.U && head === tail

  when(io.parse2Copy.fire) {
    newObjAddr := io.parse2Copy.bits.newObjAddr

    io.readMem.valid := true.B
    io.readMem.bits := io.parse2Copy.bits.objAddr
  }.otherwise {
    io.readMem.valid := size =/= 0.U && !((head - tail === 1.U) || ((tail - head + 1.U) === CopyEntry.U))
    io.readMem.bits := objAddr
  }

  when(io.parse2Copy.fire) {
    task_valid := true.B
  }.elsewhen(io.copyDone) {
    task_valid := false.B
  }

  // 之前在parse2Copy.fire时已经发出一次readMem请求
  // 这次握手成功 则发送下一次
  when(io.parse2Copy.fire && io.readMem.fire) {
    objAddr := io.parse2Copy.bits.objAddr + 8.U
    size := io.parse2Copy.bits.size - 1.U
  }.elsewhen(io.parse2Copy.fire) { //readMem还没有握手成功
    objAddr := io.parse2Copy.bits.objAddr
    size := io.parse2Copy.bits.size
  }.elsewhen(io.readMem.fire) {
    objAddr := objAddr + 8.U
    size := size - 1.U
  }

  when(io.readMem.fire) {
    req_id(tail) := io.req_id
    when(tail + 1.U === CopyEntry.U) {
      tail := 0.U
    }.otherwise {
      tail := tail + 1.U
    }
  }

  when(io.readData.valid) {
    for(i <- 0 until CopyEntry) {
      when(data_valid(i) =/= true.B && req_id(i) === io.readData.bits.id && ((i.U >= head && i.U < tail) || (tail < head && (i.U < tail || i.U >= head)))) {
        data_valid(i) := true.B
        data(i) := io.readData.bits.data
      }
    }
  }

  io.writeMem.valid := head =/= tail && data_valid(head)
  io.writeMem.bits.addr := newObjAddr
  io.writeMem.bits.data := data(head)

  when(io.writeMem.fire) {
    data_valid(head) := false.B
    when(head + 1.U === CopyEntry.U) {
      head := 0.U
    }.otherwise {
      head := head + 1.U
    }
    newObjAddr := newObjAddr + 8.U
  }
}