package gc_acc

import chisel3._
import chisel3.util._

class GCModule extends MyACCModule with GCParameters with YGJKParameters{
  val fetch = Module(new Fetch).io
  val parse = Module(new Parse).io
  val copy = Module(new Copy).io
  val trace = Module(new Trace).io
  val remap = Module(new Remap).io
  val taskStack = Module(new TaskStack).io
  val broadcast = Module(new TopBroadcast).io

  taskStack.push <> trace.trace2Stack
  taskStack.req_id := broadcast.stackRead_req_id
  taskStack.readData <> broadcast.stackReadData

  fetch.stack2Fetch <> taskStack.pop
  fetch.preFetch <> taskStack.preFetch
  fetch.trace2Fetch <> trace.trace2Fetch
  fetch.req_id := broadcast.fetchRead_req_id
  fetch.readData <> broadcast.fetchReadData
  fetch.traceNoRef := trace.traceNoRef
  fetch.parseNoField := parse.parseNoField

  parse.fetch2Parse <> fetch.fetch2Parse
  parse.req_id := broadcast.parseRead_req_id
  parse.readData <> broadcast.parseReadData

  copy.parse2Copy <> parse.parse2Copy
  copy.req_id := broadcast.copyRead_req_id
  copy.readData <> broadcast.copyReadData

  trace.parse2Trace <> parse.parse2Trace
  trace.copyDone <> copy.copyDone
  trace.req_id := broadcast.traceRead_req_id
  trace.readData <> broadcast.traceReadData

  remap.parse2Remap <> parse.parse2Remap

  broadcast.fetchRead <> fetch.readMem
  broadcast.parseRead <> parse.readMem
  broadcast.parseWrite <> parse.writeMem
  broadcast.remapWrite <> remap.writeMem 
  broadcast.copyRead <> copy.readMem
  broadcast.copyWrite <> copy.writeMem
  broadcast.traceRead <> trace.readMem
  broadcast.stackRead <> taskStack.readBack
  broadcast.stackWrite <> taskStack.spillOut
  broadcast.req_id := io.cmd.req_id
  broadcast.readMem.ready := io.cmd.axh_cready_a
  broadcast.writeMem.ready := io.cmd.axh_cready_b
  broadcast.readData.valid := io.buffer.brvalid
  broadcast.readData.bits.id := io.buffer.id
  broadcast.readData.bits.data := io.buffer.brdata


  val s_idle :: s_start :: s_doing :: s_finish :: Nil = Enum(4)
  val state  = RegInit(s_idle)

  val run = RegInit(false.B)

  io.ctl.axh_jrunning := run
  io.ctl.axh_jdone := !run

  val config_i = RegInit(0.U(3.W))

  taskStack.memStack.top := io.ctl.config.cfgData1
  taskStack.memStack.bottom := io.ctl.config.cfgData1
  taskStack.config := config_i

  parse.toSpace := io.ctl.config.cfgData1
  parse.config := config_i

  fetch.start := state === s_start

  // 4次config
  // 0: top
  // 1: bottom
  // 2: toSpace
  // 3: start
  when(io.ctl.hax_jval && state === s_idle){  //接收到启动指令
    run := true.B
    when(config_i === ConfigStackTop.U){
      config_i := ConfigStackBottom.U
    }.elsewhen(config_i === ConfigStackBottom.U){
      config_i := ConfigToSpace.U
    }.elsewhen(config_i === ConfigToSpace.U){
      config_i := ConfigStart.U
    }
  }

  //read_req
  io.cmd.acc_req_a.valid := broadcast.readMem.valid
  io.cmd.acc_req_a.cmd := 0.U
  io.cmd.acc_req_a.addr := broadcast.readMem.bits
  io.cmd.acc_req_a.data := 0.U
  io.cmd.acc_req_a.size := 2.U

  //write_req
  io.cmd.acc_req_b.valid := broadcast.writeMem.valid
  io.cmd.acc_req_b.cmd :=  1.U
  io.cmd.acc_req_b.addr := broadcast.writeMem.bits.addr
  io.cmd.acc_req_b.data := broadcast.writeMem.bits.data
  io.cmd.acc_req_b.size := 2.U

  val total_cycles = RegInit(0.U(32.W))

  when(state === s_finish) {
    total_cycles := 0.U
  }.elsewhen(config_i > 0.U) {
    total_cycles := total_cycles + 1.U
  }

  switch(state) {
    is(s_idle) {
      when(config_i === ConfigStart.U) {
        state := s_start
      }
    }
    is(s_start) {
      state := s_doing
    }
    is(s_doing) {
      // 停止条件: 硬件栈为空 并且 所有模块 都没有在执行 都可以ready 接受 前一模块 的信息
      when(taskStack.taskDone && fetch.stack2Fetch.ready && parse.fetch2Parse.ready && copy.parse2Copy.ready && trace.parse2Trace.ready && remap.parse2Remap.ready) {
        state := s_finish
        printf(p"spillCount: ${taskStack.spillCount}\n")  // stack->nostack
        printf(p"prevCount: ${fetch.prevCount}, preCount: ${fetch.preCount}\n")
        printf(p"traceForwardCount: ${trace.traceForwardCount}, traceCount: ${trace.traceCount}\n")
        printf(p"done cycles: ${total_cycles}\n")
      }
      when(io.ctl.reset === true.B){
        state := s_idle
        config_i := 0.U
        run := false.B          
      }
    }
    is(s_finish) {
      state := s_idle
      config_i := 0.U
      run := false.B
    }
  }
}
