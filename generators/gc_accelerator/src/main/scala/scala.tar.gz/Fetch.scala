package gc_acc

import chisel3._
import chisel3.util._

class Fetch extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    // 从 遍历单元 得到的任务
    val trace2Fetch = Flipped(ValidIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val objAddr = UInt(gcDataWidth.W)
    }))

    // 硬件栈的预取
    val preFetch = Flipped(DecoupledIO(UInt(gcDataWidth.W)))

    // 从 硬件栈 得到的任务
    val stack2Fetch = Flipped(DecoupledIO(UInt(gcDataWidth.W)))

    // 取任务单元 已经处理完毕 需要送往 解析单元
    val fetch2Parse = DecoupledIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val objAddr = UInt(gcDataWidth.W)
      val markWord = UInt(gcDataWidth.W)
      val klass = UInt(gcDataWidth.W)
    })

    // 访存接口
    val readMem = DecoupledIO(UInt(addrWidth.W))

    // 为请求分配一个 id
    val req_id = Input(UInt(reqNum.W))

    // 访存响应数据
    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))

    // 遍历单元 通知 无新的引用字段 入 硬件栈 向硬件栈取新任务
    val traceNoRef = Input(Bool())

    // 解析单元 通知 正在处理的对象字段为空或者已经被标记过 直接取新的
    val parseNoField = Input(Bool())

    // 是否已配置ConfigStart 主状态机状态更新为start
    val start = Input(Bool())

    // 收到的 预取 个数
    val preCount = Output(UInt(addrWidth.W))

    // 采纳的 预取 个数
    val prevCount = Output(UInt(addrWidth.W))
  })

  // 预取 task 有效信号
  val pre_valid = RegInit(false.B)

  // 引用字段
  val task = RegInit(0.U(addrWidth.W))
  val task_valid = RegInit(false.B)

  // 对象地址: 从 task引用字段地址上 读取到 对象地址
  val objAddr = RegInit(0.U(addrWidth.W))
  val objAddr_valid = RegInit(false.B)

  // markWord: 从 对象地址 上 读取到 maskWord
  val markWord = RegInit(0.U(addrWidth.W))
  val markWord_valid = RegInit(false.B)

  // Klass* 地址: 从 对象地址+8 上 读取到 klass*指针
  val klass = RegInit(0.U(addrWidth.W))
  val klass_valid = RegInit(false.B)

  val obj_req_id = RegInit(0.U(reqNum.W))
  val obj_req_valid = RegInit(false.B)

  // 发出 读取 markWord 的请求
  val markWord_req_id = RegInit(0.U(reqNum.W))
  val markWord_req_valid = RegInit(false.B)

  // 发出 读取 Klass *指针 的请求
  val klass_req_id = RegInit(0.U(reqNum.W))
  val klass_req_valid = RegInit(false.B)

  // 三次访存
  // 0: 通过 task引用字段 读取待处理对象地址 objAddr
  // 1: 通过待处理对象地址 读取 markWord
  // 2: 通过待处理对象地址 读取 klass*
  val readCount = RegInit(0.U(3.W))

  val traceNoRef = RegInit(false.B)
  val parseNoField = RegInit(false.B)

  val preCount = RegInit(0.U(addrWidth.W))
  val prevCount = RegInit(0.U(addrWidth.W))

  io.preCount := preCount
  io.prevCount := prevCount

  //可以接收 硬件栈 送来的数据: 遍历单元通知没有引用或者即将没有 解析单元通知已经标记或者没有字段或者即将 刚开始启动
  io.stack2Fetch.ready := io.traceNoRef || traceNoRef || io.parseNoField || parseNoField || io.start

  // 1）Trace传来数据，是否有预取都使用新数据
  // 2）Trace通知无引用，有预取使用预取，出栈数据与预取数据相同
  // 3）Trace通知无引用，有预取但没做完，继续等待做完
  // 4）Trace通知无引用，无预取，使用出栈数据
  // 4) 预取，不送到Parse

  // 根据io.stack2Fetch.ready的赋值条件 设置下面的when-elsewhen-elsewhen 先处理远流水阶段的请求
  when(io.stack2Fetch.fire) { //traceNoRef parseNoField是 stack2Fetch.ready的条件 这里已经握手成功 可以复位这些条件
    traceNoRef := false.B
    parseNoField := false.B
  }.elsewhen(io.traceNoRef || io.start) { //start的优先级也比较高 可以单独放置也可以和traceNoRef放一块判断
    traceNoRef := true.B
  }.elsewhen(io.parseNoField) {
    parseNoField := true.B
  }

  // preFetch.ready 必须保证 当前没有在处理的task 当期没有未使用的预取 遍历单元不会来送任务 不会接收硬件栈的任务
  // 这样保证 预取只有在 Fetch空闲时 接收 不会 覆盖掉 遍历单元 和 硬件栈 的任务
  io.preFetch.ready := !task_valid && !pre_valid && !io.trace2Fetch.valid && !io.stack2Fetch.ready

  // fetch2Parse valid Enable: 当Parse需要的task、objAddr、markWord、klass均有效时 使能
  io.fetch2Parse.valid := task_valid && objAddr_valid && markWord_valid && klass_valid

  io.fetch2Parse.bits.task := task
  io.fetch2Parse.bits.objAddr := objAddr
  io.fetch2Parse.bits.klass := klass
  io.fetch2Parse.bits.markWord := markWord

  // 遍历单元 传来的数据 已经有了 引用字段地址 + 对象地址 直接进行 cnt=1 的第二次访存 获得markWord
  when(io.trace2Fetch.valid) {
    task := io.trace2Fetch.bits.task
    objAddr := io.trace2Fetch.bits.objAddr

    // 进行 cnt=1 的 第二次 访存
    io.readMem.bits := io.trace2Fetch.bits.objAddr + MarkWordOff.U
    io.readMem.valid := true.B

    task_valid := true.B
    pre_valid := false.B
  }.elsewhen(io.stack2Fetch.fire) {
    // 硬件栈 送来的 数据 此时没有引用入栈 可以考虑预取
    // 没有预取 或者 硬件栈栈顶 有变化 则从 栈中取数据 进行 cnt=0 的 第一次访存
    when(!pre_valid || io.stack2Fetch.bits =/= task) {
      task := io.stack2Fetch.bits
      io.readMem.bits := io.stack2Fetch.bits
      io.readMem.valid := true.B
    }.otherwise{
      // 否则 使用预取数据
      io.readMem.bits := Mux(readCount === 0.U, task, Mux(readCount === 1.U, objAddr + MarkWordOff.U, objAddr + KlassOff.U))
      io.readMem.valid := (task_valid || pre_valid) && (readCount === 0.U || (readCount >= 1.U && readCount < 3.U && objAddr_valid))

      prevCount := prevCount + 1.U //记录预取被采用个数
    }
    task_valid := true.B
    pre_valid := false.B
  }.elsewhen(io.preFetch.fire) {
    // 保存这次的 预取数据
    task := io.preFetch.bits
    pre_valid := true.B

    // 并且 在 其他单元不访存时 发出访存请求 进行 cnt=0 的 第一次访存
    // 此时的 elseWhen 已经没有 trace2Fetch stack2Fetch
    io.readMem.bits := io.preFetch.bits
    io.readMem.valid := true.B

    preCount := preCount + 1.U //记录发出预取个数
  }.elsewhen(io.fetch2Parse.fire) {
    // 取指单元的有效信息 都发出去了 这里可以复位了
    // 用一个 task_valid 来 表示 objAddr、MarkWord、Klass*等的Valid
    task_valid := false.B
    pre_valid := false.B
    io.readMem.bits := 0.U
    io.readMem.valid := false.B
  }.otherwise {
    io.readMem.bits := Mux(readCount === 0.U, task, Mux(readCount === 1.U, objAddr + MarkWordOff.U, objAddr + KlassOff.U))
    io.readMem.valid := (task_valid || pre_valid) && (readCount === 0.U || (readCount >= 1.U && readCount < 3.U && objAddr_valid))
  }

  // 进行三次访存
  // 0: 通过task 读取 待处理对象地址
  // 1: 读取markWord
  // 2: 读取klass
  when(io.readMem.fire) {

    // 遍历单元 读取 MarkWord
    when(io.trace2Fetch.valid || readCount === 1.U){
      markWord_req_id := io.req_id
      markWord_req_valid := true.B
      readCount := 2.U
      // 复位其他请求 无效
      when(io.trace2Fetch.valid) {
        obj_req_valid := false.B
        klass_req_valid := false.B
      }
    }.elsewhen(readCount === 0.U || (io.stack2Fetch.fire && io.fetch2Parse.fire)) {
      // readCount === 0 时
      // io.stack2Fetch && io.fetch2Parse : 即 fetch的刚好流出 stack的刚好流入
      obj_req_id := io.req_id
      obj_req_valid := true.B
      markWord_req_valid := false.B
      klass_req_valid := false.B
      readCount := 1.U
    }.otherwise {
      klass_req_id := io.req_id
      klass_req_valid := true.B
      readCount := 3.U
    }
  }.elsewhen(io.trace2Fetch.valid || io.fetch2Parse.fire) {
    when(io.trace2Fetch.valid) {
      readCount := 1.U
    }.otherwise {
      readCount := 0.U
    }

    // 这里的复位是因为 当前任务已经切换 如果 不清0 那么可能会出现响应错误的情况
    obj_req_valid := false.B
    markWord_req_valid := false.B
    klass_req_valid := false.B
  }

  when(io.trace2Fetch.valid || io.fetch2Parse.fire) {
    when(io.trace2Fetch.valid) {
      objAddr_valid := true.B
    }.otherwise {
      objAddr_valid := false.B
    }
    markWord_valid := false.B
    klass_valid := false.B
  }.elsewhen(io.readData.valid) { //这里的为什么在elsewhen 因为上面的trace2Fetch.valid fetch2Parse 会改变objAddr_valid 和下面的更改是互斥的
    when(obj_req_valid && io.readData.bits.id === obj_req_id) {
      objAddr := io.readData.bits.data
      objAddr_valid := true.B
      obj_req_valid := false.B
    }.elsewhen(markWord_req_valid && io.readData.bits.id === markWord_req_id) {
      markWord := io.readData.bits.data
      markWord_valid := true.B
      markWord_req_valid := false.B
    }.elsewhen(klass_req_valid && io.readData.bits.id === klass_req_id) {
      klass := io.readData.bits.data
      klass_valid := true.B
      klass_req_valid := false.B
    }
  }

}