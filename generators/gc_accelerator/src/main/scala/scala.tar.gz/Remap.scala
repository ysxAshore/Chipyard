package gc_acc

import chisel3._
import chisel3.util._

// 更新引用
// 是将 父对象 中对 子对象 的引用地址更新
// 因为每一个task 都是 父对象 的 引用类型字段地址
// 所以只需要在 这个地址上 写入 newObjAddr 即可
class Remap extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    val parse2Remap = Flipped(DecoupledIO(new Bundle{
      val task = UInt(gcDataWidth.W)
      val newObjAddr = UInt(gcDataWidth.W)
    }))

    val writeMem = DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    })
  })

  val task = RegInit(0.U(gcDataWidth.W))
  val task_valid = RegInit(false.B)
  val newObjAddr = RegInit(0.U(gcDataWidth.W)) 

  io.parse2Remap.ready := !task_valid

  when(io.parse2Remap.fire) {
    io.writeMem.valid := true.B
    io.writeMem.bits.addr := io.parse2Remap.bits.task
    io.writeMem.bits.data := io.parse2Remap.bits.newObjAddr
    
    task := io.parse2Remap.bits.task
    newObjAddr := io.parse2Remap.bits.newObjAddr
  }.otherwise {
    io.writeMem.valid := task_valid
    io.writeMem.bits.addr := task
    io.writeMem.bits.data := newObjAddr
  }

  when(io.writeMem.fire) {
    task_valid := false.B
  }.elsewhen(io.parse2Remap.fire) {
    task_valid := true.B
  }
}
