package gc_acc

import boom.v3.common._
import chisel3._
import chisel3.util._
import org.chipsalliance.cde.config.Parameters
import freechips.rocketchip.tile._
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.tilelink._
import org.chipsalliance.cde.config._

class WithGCAcc(EnableGCAccList : Seq[Int]) extends Config((site,here,up) => {
  case BuildRoCC => up(BuildRoCC, site) ++ EnableGCAccList.collect {
    case tileId if tileId == site(TileKey).tileId =>
      (p:Parameters) => {
        println("[CGCAcc2YGJK] TileID: " + tileId)
        val regWidth = 32 // 寄存器位宽
        val gc_acc = LazyModule(new RoCC2GCAcc(OpcodeSet.all)(p))
        gc_acc
      }

  }
})

class GCAcc2TL(implicit p: Parameters) extends LazyModule with YGJKParameters {
  lazy val module = new GCAcc2TLImp(this)
  val node = TLClientNode(Seq(TLClientPortParameters(Seq(TLClientParameters(
    name = "GCAcc",
    sourceId = IdRange(0, sourceNum))))))
}

class GCAcc2TLImp(outer: GCAcc2TL) extends LazyModuleImp(outer) with YGJKParameters {
  val edge = outer.node.edges.out(0)
  val (tl_out, _) = outer.node.out(0)

  val blkBytes = 8
  val lgBlkBytes = 3
  val io = IO(new Bundle{
    val req_id = Output(UInt(5.W))
    val req = Flipped(Decoupled(new BoomBundle{
      val addr = UInt(paddrBits.W)
      val data = UInt((JKDataNum * encDataBits).W)
      val cmd = UInt(2.W)
      val size = UInt(3.W) // log2(bytes)
      val mask = UInt(blkBytes.W)
    }))

    val resp = Valid(new Bundle{
      val data = UInt((JKDataNum * encDataBits).W)
      val id = UInt(5.W)
    })
  })

  def getoff(addr: UInt): UInt = addr(lgBlkBytes - 1, 0)

  //  val mask = VecInit.tabulate(blkBytes){i => io.req.bits.mask((i.U >> io.req.bits.size).asUInt())}.asUInt()
  val masks = VecInit.tabulate(7){ i => VecInit.tabulate(blkBytes){ j => io.req.bits.mask(j >> i)}.asUInt }
  val data = io.req.bits.data << (getoff(io.req.bits.addr) << 3)
  val offset = RegEnable(getoff(io.req.bits.addr), tl_out.a.fire)
  val busy = RegInit(VecInit(Seq.fill(sourceNum)(false.B)))

  val id = WireInit(0.U(5.W))

  //  val i = Wire(UInt(3.W))
  for(i <- 0 until sourceNum){
    when(busy(i) === false.B){
      id := i.U
    }
  }
  io.req_id := id

  when(!(busy.reduce(_&_))){
    when(tl_out.a.fire){
      busy(id):=true.B
    }
  }

  when(tl_out.d.fire){
    busy(tl_out.d.bits.source) := false.B
  }

  tl_out.a.valid := io.req.valid && !(busy.reduce(_&_))
  tl_out.a.bits := Mux1H(Seq(
    (io.req.bits.cmd === 0.U) -> edge.Get(id, io.req.bits.addr, io.req.bits.size)._2,
    (io.req.bits.cmd === 1.U) -> edge.Put(id, io.req.bits.addr, io.req.bits.size, data)._2,
    (io.req.bits.cmd === 2.U) -> edge.Get(id, io.req.bits.addr, lgBlkBytes.U)._2,
    (io.req.bits.cmd === 3.U) -> edge.Put(id, io.req.bits.addr, lgBlkBytes.U, data, masks(io.req.bits.size))._2
  ))


  tl_out.d.ready := true.B
  io.resp.valid := tl_out.d.valid && tl_out.d.bits.opcode === TLMessages.AccessAckData
  io.req.ready := tl_out.a.ready && !(busy.reduce(_&_))
  io.resp.bits.data := tl_out.d.bits.data >> (offset << 3.U).asUInt
  io.resp.bits.id := tl_out.d.bits.source

  //  when(io.req.fire() && (io.req.bits.cmd === 3.U)){
  //    edge.slave.slaves.foreach(para => printf(p"${para.supportsPutPartial}"))
  //    assert(edge.slave.supportsPutPartialSafe(io.req.bits.addr, lgBlkBytes.U))
  //  }

}
class RoCC2GCAcc(opcodes: OpcodeSet)(implicit p: Parameters) extends LazyRoCC(opcodes) {
  override lazy val module = new GCAccTile(this)
  //  lazy val mem = LazyModule(new YgTLpfCache)
  lazy val mem = LazyModule(new GCAcc2TL)
  tlNode := TLWidthWidget(8) := mem.node
}

class GCAccTile(outer: RoCC2GCAcc)(implicit p: Parameters) extends LazyRoCCModuleImp(outer)
  with YGJKParameters
  with HasBoomCoreParameters
  with L0cacheParameters {

  val acc = p(BuildYGAC)(p)
  val mem = outer.mem.module
  val lmmu = Module(new LMMU)

  val jk_idle :: jk_compute :: jk_resp :: jk_lmmu_miss  :: Nil = Enum(4)
  val jk_state = RegInit(jk_idle)

  // RoCC指令中的寄存器 func字段
  val rs1 = RegInit(0.U(64.W))
  val rs2 = RegInit(0.U(64.W))
  val rd = RegInit(0.U(5.W))
  val func = RegInit(0.U(7.W))

  val accInstValid = RegInit(false.B)
  val ac_busy = RegInit(false.B)
  val canResp = RegInit(false.B)
  val interrupt_end = RegInit(true.B)

  val missAddr = RegInit(0.U(vaddrBits.W))

  val cache_miss = RegInit(0.U(32.W))
  val cycles_compute = RegInit(0.U(32.W))
  val cycles_total = RegInit(0.U(32.W))
  val cycles_compute_only = RegInit(0.U(32.W))
  val cycles_lmmu_miss = RegInit(0.U(32.W))

  //0-没有需要touch的地址 1-touch请求 2-等待touch返回
  val touch_addr = RegInit(0.U(32.W))
  val touch_state = RegInit(0.U(2.W))

  val req = WireInit(acc.io.cmd.acc_req_a)

  lmmu.io.req.vaddr0_valid := (acc.io.cmd.acc_req_a.valid && jk_state === jk_compute) || touch_state === 1.U
  lmmu.io.req.vaddr0 := Mux(acc.io.cmd.acc_req_a.valid, acc.io.cmd.acc_req_a.addr, touch_addr)
  lmmu.io.req.vaddr1_valid := acc.io.cmd.acc_req_b.valid && jk_state === jk_compute
  lmmu.io.req.vaddr1 := acc.io.cmd.acc_req_b.addr

  when(touch_state===1.U || touch_state===2.U){
    // printf(p"touch_addr ${touch_addr}\n")
  }

  req.valid := lmmu.io.resp.paddr0_valid
  req.addr := lmmu.io.resp.paddr0
  when(lmmu.io.resp.paddr1_valid) {
    req := acc.io.cmd.acc_req_b
    req.valid := lmmu.io.resp.paddr1_valid
    req.addr := lmmu.io.resp.paddr1
  }.otherwise{
    req := acc.io.cmd.acc_req_a
    req.valid := lmmu.io.resp.paddr0_valid | touch_state === 1.U
    req.addr := lmmu.io.resp.paddr0
  }

  when(!acc.io.cmd.acc_req_a.valid && !acc.io.cmd.acc_req_b.valid && touch_state === 1.U){
    touch_state := 2.U
  }.elsewhen(mem.io.resp.valid && touch_state === 2.U){
    touch_state := 0.U
  }

  mem.io.req.valid := req.valid
  mem.io.req.bits.addr := req.addr
  mem.io.req.bits.data := req.data
  mem.io.req.bits.cmd := req.cmd
  mem.io.req.bits.size := 3.U
  mem.io.req.bits.mask := -1.S(8.W).asUInt

  when(ac_busy){
    cycles_compute := cycles_compute + 1.U
  }

  when(!interrupt_end){
    cycles_total := cycles_total + 1.U
  }

  when(jk_state === jk_lmmu_miss){
    cycles_lmmu_miss := cycles_lmmu_miss + 1.U
  }

  //decode & initial & response
  rd := io.cmd.bits.inst.rd
  io.cmd.ready := !canResp
  when(io.cmd.fire && io.cmd.bits.inst.opcode === "h0B".U && io.cmd.bits.inst.funct === 0.U) { // //rocc_req  fire  cmd come
    rs1 := io.cmd.bits.rs1
    rs2 := io.cmd.bits.rs2
    func := io.cmd.bits.inst.funct
    accInstValid := true.B
    when(jk_state===jk_idle){

    }
    cycles_lmmu_miss := 0.U
    ac_busy := true.B
    interrupt_end := false.B
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h0B".U && io.cmd.bits.inst.funct === 1.U) {
    touch_addr := io.cmd.bits.rs1
    touch_state := 1.U
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h0B".U && io.cmd.bits.inst.funct === 2.U) {
    rs1 := io.cmd.bits.rs1
    rs2 := io.cmd.bits.rs2
    func := io.cmd.bits.inst.funct
    cycles_compute_only := 0.U
  }.otherwise {
    accInstValid := false.B
  }

  when(io.cmd.fire){
    canResp := true.B
    printf(p"io.cmd.fire()  io.cmd.bits.rs1 ${io.cmd.bits.rs1} io.cmd.bits.rs2 ${io.cmd.bits.rs2}\n")
  }


  val rd_data = RegInit(0.U(32.W))

  io.resp.bits.data := rd_data
  io.resp.valid := canResp
  io.resp.bits.rd := rd
  when(io.resp.fire) {
    canResp := false.B
  }


  lmmu.io.core.refillVaddr := io.cmd.bits.rs1
  lmmu.io.core.refillPaddr := io.cmd.bits.rs2
  when(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 4.U){
    lmmu.io.core.refill_valid := true.B
    printf(p"io.cmd.bits.rs1 ${io.cmd.bits.rs1} io.cmd.bits.rs2 ${io.cmd.bits.rs2}\n")
    lmmu.io.core.refillVaddr := io.cmd.bits.rs1
    lmmu.io.core.refillPaddr := io.cmd.bits.rs2
  }.otherwise{
    lmmu.io.core.refill_valid := false.B
  }


  when(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 2.U){
    //    printf(p"lmmu funct === 2\n")
    lmmu.io.core.useVM := true.B
    lmmu.io.core.useVM_valid := true.B
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 3.U){
    lmmu.io.core.useVM := false.B
    lmmu.io.core.useVM_valid := true.B
  }.otherwise{
    lmmu.io.core.useVM := false.B
    lmmu.io.core.useVM_valid := false.B
  }

  // 获得性能计数
  when(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 1.U){
    when(jk_state=/=jk_resp){
      rd_data := missAddr
    }.otherwise{
      rd_data := missAddr + 1.U
    }
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 5.U){
    rd_data := cache_miss
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 6.U){
    rd_data := cycles_compute_only
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 7.U){
    //    printf(p"&&&&&jk_state ${jk_state}\n")
    when(jk_state === jk_resp){
      //      printf(p"jk_state === jk_resp\n")
      rd_data := 10.U
    }.otherwise{
      //      printf(p"jk_state =/= jk_resp\n")
      rd_data := 0.U
    }
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 8.U){
    rd_data := cycles_compute
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 9.U){
    rd_data := cycles_total
  }.elsewhen(io.cmd.fire && io.cmd.bits.inst.opcode === "h0B".U && io.cmd.bits.inst.funct === 3.U){
    rd_data := acc.io.ctl.axh_jrunning
  }.otherwise{
    rd_data := ac_busy
  }

  acc.io.cmd.axh_cready_a := mem.io.req.ready && ! lmmu.io.req.vaddr1_valid && jk_state === jk_compute && !lmmu.io.resp.miss
  acc.io.cmd.axh_cready_b := mem.io.req.ready && jk_state === jk_compute && !lmmu.io.resp.miss

  acc.io.cmd.req_id := mem.io.req_id

  acc.io.ctl.hax_jval := accInstValid
  acc.io.ctl.config.cfgData1 := rs1
  acc.io.ctl.config.cfgData2 := rs2
  /*
    acc.io.config.valid := accInstValid
    acc.io.config.bits.cfgData1 := rs1
    acc.io.config.bits.cfgData2 := rs2

    acc.io.query.rs1 := rs1
    acc.io.query.rs2 := rs2
  */
  //sdma.io.jk.buffer.brdata := VecInit.tabulate(JKDataNum) { i => mem.io.resp.bits.data((i + 1) * bufferLine - 1, i * bufferLine)}
  acc.io.buffer.brdata := mem.io.resp.bits.data
  acc.io.buffer.brvalid := mem.io.resp.valid && touch_state =/= 2.U
  acc.io.buffer.id := mem.io.resp.bits.id

  //sdma.io.jk.buffer.bwdata := VecInit.tabulate(JKDataNum) { i => mem.io.resp.bits.data((i + 1) * bufferLine - 1, i * bufferLine)}
  acc.io.buffer.bwdata := mem.io.resp.bits.data
  acc.io.buffer.bwvalid := mem.io.resp.valid && touch_state =/= 2.U

  io.interrupt := false.B

  acc.io.ctl.reset := false.B

  switch(jk_state) {
    is(jk_idle) {
      cycles_compute := 0.U

      jk_state := Mux(ac_busy, jk_compute, jk_idle)
      when(ac_busy){
        cycles_total := 0.U
      }
    }

    is(jk_compute) {
      when(io.cmd.fire && io.cmd.bits.inst.opcode === "h0B".U && io.cmd.bits.inst.funct === 2.U){
        cycles_compute_only := 0.U
      }.otherwise{
        cycles_compute_only := cycles_compute_only + 1.U
      }
      when(lmmu.io.resp.miss){
        missAddr := lmmu.io.resp.missAddr
        jk_state := jk_lmmu_miss
      }
      when(acc.io.ctl.axh_jdone && mem.io.req.ready) {
        jk_state := jk_resp
      }
      when(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 10.U){
        ac_busy := false.B
        acc.io.ctl.reset := true.B
        jk_state := jk_idle
      }
    }
    is(jk_lmmu_miss){
      io.interrupt := true.B
      /*
            when(io.cmd.fire() && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 4.U){
              lmmu.io.core.refill_valid := true.B
              lmmu.io.core.refillVaddr := io.cmd.bits.rs1
              lmmu.io.core.refillPaddr := io.cmd.bits.rs2

            }
      */
      jk_state := jk_compute
    }
    is(jk_resp) {
      io.interrupt := true.B
      ac_busy := false.B
      when(io.cmd.fire && io.cmd.bits.inst.opcode === "h2B".U && io.cmd.bits.inst.funct === 0.U){
        interrupt_end := true.B
        jk_state := jk_idle
      }
    }
  }
}

