package gc_acc

import chisel3._
import chisel3.util._

class TopBroadcast extends Module with GCParameters with YGJKParameters{
  val io = IO(new Bundle{
    val fetchRead = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val fetchRead_req_id = Output(UInt(reqNum.W))
    val fetchReadData = ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    })

    val parseRead = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val parseRead_req_id = Output(UInt(reqNum.W))
    val parseReadData = ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    })

    val parseWrite = Flipped(DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    }))

    val remapWrite = Flipped(DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    }))

    val copyRead = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val copyRead_req_id = Output(UInt(reqNum.W))
    val copyReadData = ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    })
    
    val copyWrite = Flipped(DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    }))

    val traceRead = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val traceRead_req_id = Output(UInt(reqNum.W))
    val traceReadData = ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    })

    val stackRead = Flipped(DecoupledIO(UInt(gcDataWidth.W)))
    val stackRead_req_id = Output(UInt(reqNum.W))
    val stackReadData = ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    })
    
    val stackWrite = Flipped(DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    }))

    val readMem = DecoupledIO(UInt(addrWidth.W))
    val writeMem = DecoupledIO(new Bundle{
      val addr = UInt(gcDataWidth.W)  
      val data = UInt(gcDataWidth.W)
    }) 
    val req_id = Input(UInt(reqNum.W))
    val readData = Flipped(ValidIO(new Bundle{
      val data = UInt(gcDataWidth.W)
      val id = UInt(reqNum.W)
    }))
  })

  // 优先级 copyRead>copyWrite>stackWrite>traceRead>remapWrite>parseRead>parseWrite>stackRead>fetchRead
  // read 优先级: copyRead > traceRead > parseRead > stackRead > fetchRead
  // write 优先级: copyWrite > stackWrite > remapWrite > parseWrite
  io.readMem.valid := io.copyRead.valid || io.traceRead.valid || io.parseRead.valid || io.stackRead.valid || io.fetchRead.valid
  io.readMem.bits := Mux(io.copyRead.valid, io.copyRead.bits, Mux(io.traceRead.valid, io.traceRead.bits, Mux(io.parseRead.valid, io.parseRead.bits, Mux(io.stackRead.valid, io.stackRead.bits, Mux(io.fetchRead.valid, io.fetchRead.bits, 0.U)))))

  io.copyRead.ready := io.readMem.ready && io.copyRead.valid
  io.copyRead_req_id := io.req_id

  io.traceRead.ready := io.readMem.ready && !io.copyRead.valid && io.traceRead.valid
  io.traceRead_req_id := io.req_id

  io.parseRead.ready := io.readMem.ready && !io.copyRead.valid && !io.traceRead.valid && io.parseRead.valid
  io.parseRead_req_id := io.req_id

  io.stackRead.ready := io.readMem.ready && !io.copyRead.valid && !io.traceRead.valid && !io.parseRead.valid && io.stackRead.valid
  io.stackRead_req_id := io.req_id

  io.fetchRead.ready := io.readMem.ready && !io.copyRead.valid && !io.traceRead.valid && !io.parseRead.valid && !io.stackRead.valid && io.fetchRead.valid
  io.fetchRead_req_id := io.req_id

  io.writeMem.valid := io.copyWrite.valid || io.stackWrite.valid || io.remapWrite.valid || io.parseWrite.valid
  io.writeMem.bits.addr := Mux(io.copyWrite.valid, io.copyWrite.bits.addr, Mux(io.stackWrite.valid, io.stackWrite.bits.addr, Mux(io.remapWrite.valid, io.remapWrite.bits.addr, Mux(io.parseWrite.valid, io.parseWrite.bits.addr, 0.U))))
  io.writeMem.bits.data := Mux(io.copyWrite.valid, io.copyWrite.bits.data, Mux(io.stackWrite.valid, io.stackWrite.bits.data, Mux(io.remapWrite.valid, io.remapWrite.bits.data, Mux(io.parseWrite.valid, io.parseWrite.bits.data, 0.U))))

  io.copyWrite.ready := io.writeMem.ready && io.copyWrite.valid
  io.stackWrite.ready := io.writeMem.ready && !io.copyWrite.valid && io.stackWrite.valid
  io.remapWrite.ready := io.writeMem.ready && !io.copyWrite.valid && !io.stackWrite.valid && io.remapWrite.valid
  io.parseWrite.ready := io.writeMem.ready && !io.copyWrite.valid && !io.stackWrite.valid && !io.remapWrite.valid && io.parseWrite.valid

  io.copyReadData.valid := io.readData.valid
  io.copyReadData.bits.id := io.readData.bits.id
  io.copyReadData.bits.data := io.readData.bits.data

  io.traceReadData.valid := io.readData.valid
  io.traceReadData.bits.id := io.readData.bits.id
  io.traceReadData.bits.data := io.readData.bits.data

  io.parseReadData.valid := io.readData.valid
  io.parseReadData.bits.id := io.readData.bits.id
  io.parseReadData.bits.data := io.readData.bits.data

  io.stackReadData.valid := io.readData.valid
  io.stackReadData.bits.id := io.readData.bits.id
  io.stackReadData.bits.data := io.readData.bits.data

  io.fetchReadData.valid := io.readData.valid
  io.fetchReadData.bits.id := io.readData.bits.id
  io.fetchReadData.bits.data := io.readData.bits.data

}