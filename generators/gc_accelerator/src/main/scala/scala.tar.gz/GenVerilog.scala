package gc_acc

import circt.stage.ChiselStage

object GenVerilog {
  def main(args: Array[String]): Unit = {
    // 如果 TaskStack 需要构造参数，按你的构造器传入
    val dut = () => new GCModule()

    // 生成 Verilog 到 verilog_output 目录
    ChiselStage.emitSystemVerilog(
      dut(),
      Array("--target-dir","verilog_output")
    )
  }
}